import streamlit as st
import pandas as pd
import plotly.express as px
import streamlit as st
import acercaDe  # Importar la página 'home.py'
import dashboard  # Importar la página 'dashboard.py'
import modelos  # Importar la página 'modelos_ml.py'
import inicio # Importar la página 'inicio.py'
import base64
import chatbot

# Definir función principal para manejar pestañas
def chatbot_page():
    st.markdown("""algo""")